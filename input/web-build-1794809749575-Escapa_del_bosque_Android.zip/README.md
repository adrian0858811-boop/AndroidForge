# Escapa del bosque — proyecto Android

Este ZIP contiene el juego HTML confirmado, las linternas añadidas y el arreglo para pausar/reanudar el bucle al cambiar de aplicación, además del icono proporcionado.

## Crear el APK desde GitHub (también desde Android)
1. Descomprime este ZIP.
2. Sube el contenido de la carpeta a un repositorio de GitHub (no subas la carpeta contenedora como una subcarpeta adicional).
3. Abre la pestaña **Actions**.
4. Ejecuta **Build Android APK** con **Run workflow**, o espera a que termine el flujo automático.
5. En la ejecución completada, baja a **Artifacts** y descarga **Escapa-del-bosque-APK**.
6. Abre el ZIP descargado y extrae `app-debug.apk` para instalarlo.

La primera compilación necesita conexión a internet para descargar las dependencias Android y Three.js se carga desde CDN al abrir el juego.
