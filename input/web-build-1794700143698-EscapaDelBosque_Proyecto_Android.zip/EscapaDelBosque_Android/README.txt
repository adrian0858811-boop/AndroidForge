ESCAPA DEL BOSQUE - PROYECTO ANDROID

Este proyecto envuelve el juego HTML en una aplicación Android de pantalla completa.
Incluye el HTML con los efectos de sonido incorporados.

IMPORTANTE:
El juego carga Three.js desde cdnjs (internet), igual que el HTML original.
Por eso la aplicación solicita permiso INTERNET y necesita conexión para cargar el motor 3D.

COMO GENERAR EL APK:
1. Instala Android Studio en una computadora.
2. Descomprime este ZIP.
3. En Android Studio elige Open y selecciona la carpeta EscapaDelBosque_Android.
4. Espera a que Gradle sincronice el proyecto.
5. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio generará el APK y mostrará la ubicación para abrirlo.

NOTA:
Aquí se preparó el proyecto Android, pero no se compiló un APK firmado/instalable:
este entorno no tiene Android SDK ni Gradle instalados.
