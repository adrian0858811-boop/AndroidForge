ESCAPA DEL BOSQUE - PROYECTO ANDROID

Este proyecto envuelve tu archivo HTML original en una aplicación Android
(WebView). El juego se conserva en app/src/main/assets/index.html.

PARA OBTENER EL APK DESDE TU CELULAR (SIN COMPUTADORA):

1. Descomprime este ZIP en tu teléfono.
2. Entra a https://github.com e inicia sesión.
3. Crea un repositorio nuevo llamado EscapaDelBosque-Android.
   Déjalo público o privado; cualquiera sirve para compilar.
4. Sube TODOS los archivos y carpetas de este proyecto al repositorio.
   Es importante conservar la estructura de carpetas.
5. Abre la pestaña "Actions" del repositorio.
6. Si GitHub pregunta si quieres habilitar workflows, acepta.
7. Entra al flujo "Construir APK de Escapa del bosque".
8. Pulsa "Run workflow" y confirma.
9. Espera a que termine con una marca verde.
10. Abre la ejecución terminada, baja hasta "Artifacts" y descarga
    "Escapa-del-bosque-APK".
11. Descomprime ese archivo descargado. Dentro estará app-debug.apk.
12. Toca el APK para instalarlo. Android puede pedirte permiso para
    instalar aplicaciones desde esa fuente.

NOTAS:
- La app está configurada en orientación horizontal.
- Requiere conexión a internet para descargar Three.js desde el CDN
  que ya utiliza tu HTML.
- Este proyecto no cambia la lógica ni los gráficos del juego.
- El APK generado por assembleDebug es de prueba/instalación directa.
- Si GitHub muestra un error, comparte una captura del error para corregirlo.
