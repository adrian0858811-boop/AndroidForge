ESCAPA DEL BOSQUE - PRIMERA VERSION CON ICONO

Este proyecto usa la primera version del juego (Escapa del bosque (3).html).
El icono de la aplicacion es la imagen proporcionada por el usuario.

Para generar el APK:
1. Sube el contenido de esta carpeta a un repositorio de GitHub.
2. Abre la pestaña Actions.
3. Ejecuta el workflow Build Android APK.
4. Cuando termine correctamente, descarga el artefacto APK y extrae app-debug.apk.

El juego se abre dentro de una aplicacion Android mediante WebView.
Se requiere conexion a internet para cargar las dependencias externas que usa el HTML.
